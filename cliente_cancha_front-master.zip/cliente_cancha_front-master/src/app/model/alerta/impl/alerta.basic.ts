export class AlertaBasic implements Alerta {
    tipo:string;
    descripcion:string;
}   