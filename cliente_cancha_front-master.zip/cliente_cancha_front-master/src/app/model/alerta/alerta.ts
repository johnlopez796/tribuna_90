interface Alerta {
    tipo:string;
    descripcion:string;
}   