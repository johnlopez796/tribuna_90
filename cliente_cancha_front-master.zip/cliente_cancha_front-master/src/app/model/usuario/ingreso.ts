export class Ingreso {
    nickName: String;
    password: String;
}