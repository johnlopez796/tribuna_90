export class Usuario {
    apellidos: string;
    clave: string;
    documento: string;
    email: string;
    fechaNacimiento: string;
    id: string;
    nickname: string;
    nombres: string;
    tipoDocumento: string;
    token: string;
}