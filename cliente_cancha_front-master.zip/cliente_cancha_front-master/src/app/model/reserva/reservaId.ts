export class ReservaId {
    idReserva:string;
}