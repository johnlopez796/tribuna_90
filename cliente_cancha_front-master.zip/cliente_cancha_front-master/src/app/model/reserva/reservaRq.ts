export class ReservaRq {
    fechaReserva:String;
    idCancha:String;
}