export class Horario {
    idCancha: string;
    tarifa: number;
    horaIni: Date;
    horaFin: Date;
    tipoGrama: string;
    tipoTecho: string;
    capacidad: number;
}