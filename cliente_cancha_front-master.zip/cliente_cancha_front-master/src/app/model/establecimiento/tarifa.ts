export class Tarifa {
    id: string;
    estado: string;
    horaFin: number;
    horaIni: number;
    nombre: string;
    tarifa: number;
}