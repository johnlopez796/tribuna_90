export const environment = {
  production: true,
  apiIngreso: 'http://localhost:8762/user'
};
 